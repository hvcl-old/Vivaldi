MPI for Python
==============

:Author:       Lisandro Dalcin
:Contact:      dalcinl@gmail.com
:Web Site:     http://mpi4py.googlecode.com
:Organization: `CIMEC <http://www.cimec.org.ar/>`_
:Address:      CCT CONICET, (3000) Santa Fe, Argentina
:Date:         |today|
:Copyright:    This document has been placed in the public domain.

.. include:: abstract.txt


Contents
========

.. include:: toctree.txt


.. Indices and tables
.. ==================
..
.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`
